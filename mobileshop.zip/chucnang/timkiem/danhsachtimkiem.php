<link rel="stylesheet" type="text/css" href="css/danhsachtimkiem.css" />

            	<div class="prd-block">
                	<h2>kết quả tìm được với từ khóa <span class="skeyword">"điện thoại samsung"</span></h2>
                    <div class="pr-list">
                    	<div class="prd-item">
                        	<a href="#"><img width="80" height="144" src="anh/prd01.jpg" /></a>
                            <h3><a href="#">Samsung Galaxy Note Trắng</a></h3>
                            <p>Bảo hành: 12 Tháng</p>
                            <p>Tình trạng: Máy Mới 100%</p>
                            <p class="price"><span>Giá: 6.800.000 VNĐ</span></p>
                        </div>
                        <div class="prd-item">
                        	<a href="#"><img width="80" height="144" src="anh/prd02.jpg" /></a>
                            <h3><a href="#">Samsung Galaxy Note Trắng</a></h3>
                            <p>Bảo hành: 12 Tháng</p>
                            <p>Tình trạng: Máy Mới 100%</p>
                            <p class="price"><span>Giá: 6.800.000 VNĐ</span></p>
                        </div>
                        <div class="prd-item">
                        	<a href="#"><img width="80" height="144" src="anh/prd03.jpg" /></a>
                            <h3><a href="#">Samsung Galaxy Note Trắng</a></h3>
                            <p>Bảo hành: 12 Tháng</p>
                            <p>Tình trạng: Máy Mới 100%</p>
                            <p class="price"><span>Giá: 6.800.000 VNĐ</span></p>
                        </div>
                        
                        <div class="clear"></div>
                        
                        <div class="prd-item">
                        	<a href="#"><img width="80" height="144" src="anh/prd04.jpg" /></a>
                            <h3><a href="#">Samsung Galaxy Note Trắng</a></h3>
                            <p>Bảo hành: 12 Tháng</p>
                            <p>Tình trạng: Máy Mới 100%</p>
                            <p class="price"><span>Giá: 6.800.000 VNĐ</span></p>
                        </div>
                        <div class="prd-item">
                        	<a href="#"><img width="80" height="144" src="anh/prd05.jpg" /></a>
                            <h3><a href="#">Samsung Galaxy Note Trắng</a></h3>
                            <p>Bảo hành: 12 Tháng</p>
                            <p>Tình trạng: Máy Mới 100%</p>
                            <p class="price"><span>Giá: 6.800.000 VNĐ</span></p>
                        </div>
                        <div class="prd-item">
                        	<a href="#"><img width="80" height="144" src="anh/prd06.jpg" /></a>
                            <h3><a href="#">Samsung Galaxy Note Trắng</a></h3>
                            <p>Bảo hành: 12 Tháng</p>
                            <p>Tình trạng: Máy Mới 100%</p>
                            <p class="price"><span>Giá: 6.800.000 VNĐ</span></p>
                        </div>
                        
                        <div class="clear"></div>
                        
                        <div class="prd-item">
                        	<a href="#"><img width="80" height="144" src="anh/prd07.png" /></a>
                            <h3><a href="#">Samsung Galaxy Note Trắng</a></h3>
                            <p>Bảo hành: 12 Tháng</p>
                            <p>Tình trạng: Máy Mới 100%</p>
                            <p class="price"><span>Giá: 6.800.000 VNĐ</span></p>
                        </div>
                        <div class="prd-item">
                        	<a href="#"><img width="80" height="144" src="anh/prd08.png" /></a>
                            <h3><a href="#">Samsung Galaxy Note Trắng</a></h3>
                            <p>Bảo hành: 12 Tháng</p>
                            <p>Tình trạng: Máy Mới 100%</p>
                            <p class="price"><span>Giá: 6.800.000 VNĐ</span></p>
                        </div>
                        <div class="prd-item">
                        	<a href="#"><img width="80" height="144" src="anh/prd09.jpg" /></a>
                            <h3><a href="#">Samsung Galaxy Note Trắng</a></h3>
                            <p>Bảo hành: 12 Tháng</p>
                            <p>Tình trạng: Máy Mới 100%</p>
                            <p class="price"><span>Giá: 6.800.000 VNĐ</span></p>
                        </div>
                        
                        <div class="clear"></div>
                        
                        <div class="prd-item">
                        	<a href="#"><img width="80" height="144" src="anh/prd10.png" /></a>
                            <h3><a href="#">Samsung Galaxy Note Trắng</a></h3>
                            <p>Bảo hành: 12 Tháng</p>
                            <p>Tình trạng: Máy Mới 100%</p>
                            <p class="price"><span>Giá: 6.800.000 VNĐ</span></p>
                        </div>
                        <div class="prd-item">
                        	<a href="#"><img width="80" height="144" src="anh/prd11.jpg" /></a>
                            <h3><a href="#">Samsung Galaxy Note Trắng</a></h3>
                            <p>Bảo hành: 12 Tháng</p>
                            <p>Tình trạng: Máy Mới 100%</p>
                            <p class="price"><span>Giá: 6.800.000 VNĐ</span></p>
                        </div>
                        <div class="prd-item">
                        	<a href="#"><img width="80" height="144" src="anh/prd12.jpg" /></a>
                            <h3><a href="#">Samsung Galaxy Note Trắng</a></h3>
                            <p>Bảo hành: 12 Tháng</p>
                            <p>Tình trạng: Máy Mới 100%</p>
                            <p class="price"><span>Giá: 6.800.000 VNĐ</span></p>
                        </div>
                        
                        <div class="clear"></div>
                    </div>
                </div>