<form method="post" name="sform">
	<input type="submit" name="sbutton" value="" />
	<input type="text" name="stext" value="Tìm kiếm sản phầm" />
</form>