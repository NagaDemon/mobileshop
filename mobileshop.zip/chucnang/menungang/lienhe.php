<div class="prd-block">
	<h2>liên hệ</h2>
    <div class="contact">
    	<ul>
        	<li>Các bạn có thể liên hệ với Trung tâm Tin học và Công nghệ Vietpro theo các kênh sau</li>
            <li>• <span>Website:</span> <a href="http://vietpro.edu.vn">http://vietpro.edu.vn</a></li>
            <li>• <span>Hotline:</span> 0968 511 155</li>
            <li>• <span>Email:</span> <a href="#">vietpro.edu.vn@gmail.com</a></li>
            <li>• <span>Facebook:</span> <a href="http://facebook.com/tinhocvietpro">http://facebook.com/tinhocvietpro</a></li>
            <li>• <span>Địa chỉ:</span> Số 25 Ngõ 178/71 Tây Sơn, Trung Liệt, Đống Đa, Hà Nội</li>
        </ul>
    </div>
</div>