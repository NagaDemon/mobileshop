<div class="prd-block">
	<h2>dịch vụ</h2>
    <div class="services">
    	<ul>
        	<li>Trung tâm Tin học và Công nghệ Vietpro hiện đang hoạt động và cung cấp các Dịch vu về CNTT như</li>
            <li>• Đào tạo nguồn nhân lực CNTT với các chuyên ngành (Lập trình, Thiết kế, Đồ họa, Tin Văn phòng, Internet Marketing).</li>
            <li>• Dịch vụ Thiết kế website Chuyên nghiệp, Thiết kế website Giá rẻ.</li>
            <li>• Dịch vụ SEO trọn gói, SEO giá rẻ</li>
            <li>• Dịch vụ cung cấp Doamin, Hosting, Máy chủ</li>
            <li>• Tư vấn Kinh doanh, Tư vấn chiến lược, Xây dựng Thương hiệu</li>
        </ul>
    </div>
</div>