<ul>
    <li id="menu-home"><a href="index.php">trang chủ</a></li>
    <li><a href="index.php?page_layout=gioithieu">giới thiệu</a></li>
    <li><a href="index.php?page_layout=dichvu">dịch vụ</a></li>
    <li><a href="index.php?page_layout=lienhe">liên hệ</a></li>
    <li><a target="_blank" href="#">diễn đàn</a></li>
</ul>