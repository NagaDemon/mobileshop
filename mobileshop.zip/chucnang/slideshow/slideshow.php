<div id="slideshow">
    <img src="anh/ip.jpg" alt="Slideshow Image 1" class="active" />
<!--     <img src="anh/sls02.png" alt="Slideshow Image 2" />
    <img src="anh/sls03.jpg" alt="Slideshow Image 3" />
    <img src="anh/sls04.jpg" alt="Slideshow Image 4" />
    <img src="anh/sls05.png" alt="Slideshow Image 5" />
    <img src="anh/sls06.png" alt="Slideshow Image 6" /> -->
</div>