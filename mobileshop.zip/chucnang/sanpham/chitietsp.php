<?php
    $id_sp = $_GET['id_sp'];
    $sql = "SELECT * FROM sanpham INNER JOIN dmsanpham ON sanpham.id_dm =
    dmsanpham.id_dm WHERE id_sp = $id_sp";
    $query = mysql_query($sql);
    $row = mysql_fetch_array($query);
?>
<div class="prd-block">
    <div class="prd-only">
    <div class="prd-img"><img width="50%" src="quantri/anh/<?php echo
    $row['anh_sp'];?>" /></div>
    <div class="prd-intro">
        <h3><?php echo $row['ten_sp'];?></h3>
        <p>Giá sản phẩm: <span><?php echo $row['gia_sp'];?> VNÐ</span></p>
        <table>
            <tr>
                <td width="30%"><span>Bảo hành:</span></td>
                <td>• <?php echo $row['bao_hanh'];?></td>
            </tr>
            <tr>
                <td><span>Ði kèm:</span></td>
                <td>• <?php echo $row['phu_kien'];?></td>
            </tr>
            <tr>
                <td><span>Tình trạng:</span></td>
                <td>• <?php echo $row['tinh_trang'];?></td>
            </tr>
            <tr>
                <td><span>Khuyến Mãi:</span></td>
                <td>• <?php echo $row['khuyen_mai'];?></td>
            </tr>
            <tr>
                <td><span>Còn hàng:</span></td>
                <td>• <?php echo $row['trang_thai'];?></td>
            </tr>
        </table>
        <p class="add-cart"><a href="#"><span>ð.t mua</span></a></p>
    </div>
    <div class="clear"></div>
    <div class="prd-details">
        <p><?php echo $row['chi_tiet_sp'];?></p>
    </div>
    </div>
    
    <div class="prd-comment">
    <h3>Bình luận sản phẩm</h3>
    <form method="post">
    	<ul>
        	<li class="required">Tên <br /><input type="text" name="ten" /> <span>(*)</span></li>
            <li class="required">Số điện thoại <br /><input type="text" name="dien_thoai" /> <span>(*)</span></li>
            <li class="required">Nội dung <br /><textarea name="binh_luan"></textarea> <span>(*)</span></li>
            <li><input type="submit" name="submit" value="Bình luận" /></li>
        </ul>
    </form>
    </div>
    
    <div class="comment-list">
    	<ul>
        	<li class="com-title">Vietpro Education<br /><span>2013-05-06 9:19:30</span></li>
            <li class="com-details">HTC One X 32GB là sản phẩm đáng chờ đợi nhất trong năm nay, với cấu hình mạnh và giá thành tương đối mềm so với các dòng Smart Phone của các hãng khác</li>
        </ul>
        
        <ul>
        	<li class="com-title">Vietpro Education<br /><span>2013-05-06 9:19:30</span></li>
            <li class="com-details">HTC One X 32GB là sản phẩm đáng chờ đợi nhất trong năm nay, với cấu hình mạnh và giá thành tương đối mềm so với các dòng Smart Phone của các hãng khác</li>
        </ul>
        
        <ul>
        	<li class="com-title">Vietpro Education<br /><span>2013-05-06 9:19:30</span></li>
            <li class="com-details">HTC One X 32GB là sản phẩm đáng chờ đợi nhất trong năm nay, với cấu hình mạnh và giá thành tương đối mềm so với các dòng Smart Phone của các hãng khác</li>
        </ul>
    </div>
    
    <div class="com-pagination"><span>1</span> <a href="#">2</a> <a href="#">3</a> <a href="#">4</a></div>
    
</div>