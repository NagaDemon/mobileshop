<div class="l-sidebar">
    <h2>tư vấn online</h2>
    <img src="anh/iphone6s.jpg" width="218px" height="160px">
</div>