<div class="l-sidebar">
    <h2>thống kê truy cập</h2>
    <div id="counter">
        <p>Hiện có <span>8686</span> người đang xem</p>
    </div>
</div>