<div class="l-sidebar">
    <h2>đối tác</h2>
    <div class="l-banner"><a href="#"><img width="216" src="anh/banner01.png" /></a></div>
</div>