<div class="prd-block">
	<h2>xác nhận hóa đơn thanh toán</h2>
    <div class="payment">
    	<table border="0px" cellpadding="0px" cellspacing="0px" width="100%">
        	<tr id="invoice-bar">
            	<td width="45%">Tên Sản phẩm</td>
                <td width="20%">Giá</td>
                <td width="15%">Số lượng</td>
                <td width="20%">Thành tiền</td>
            </tr>
            <tr>
            	<td class="prd-name">Samsung Galaxy Note Trắng</td>
                <td class="prd-price">6.800.000 VNĐ</td>
                <td class="prd-number">4</td>
                <td class="prd-total">27.200.000 VNĐ</td>
            </tr>
             <tr>
            	<td class="prd-name">Samsung Galaxy Note Trắng</td>
                <td class="prd-price">6.800.000 VNĐ</td>
                <td class="prd-number">4</td>
                <td class="prd-total">27.200.000 VNĐ</td>
            </tr>
             <tr>
            	<td class="prd-name">Samsung Galaxy Note Trắng</td>
                <td class="prd-price">6.800.000 VNĐ</td>
                <td class="prd-number">4</td>
                <td class="prd-total">27.200.000 VNĐ</td>
            </tr>
             <tr>
            	<td class="prd-name">Samsung Galaxy Note Trắng</td>
                <td class="prd-price">6.800.000 VNĐ</td>
                <td class="prd-number">4</td>
                <td class="prd-total">27.200.000 VNĐ</td>
            </tr>
            <tr>
            	<td class="prd-name">Tổng giá trị hóa đơn là:</td>
                <td colspan="2"></td>
                <td class="prd-total"><span>108.800.000 VNĐ</span></td>
            </tr>
        </table>

    </div>
    
    <div class="form-payment">
    	<form method="post">
    	<ul>
        	<li class="info-cus"><label>Tên khách hàng</label><br /><input type="text" name="ten" /> <span>(*)</span></li>
            <li class="info-cus"><label>Địa chỉ Email</label><br /><input type="text" name="mail" /> <span>(*)</span></li>
            <li class="info-cus"><label>Số Điện thoại</label><br /><input type="text" name="dt" /> <span>(*)</span></li>
            <li class="info-cus"><label>Địa chỉ nhận hàng</label><br /><input type="text" name="dc" /> <span>(*)</span></li>
            <li><input type="submit" name="submit" value="Xác nhận mua hàng" /> <input type="reset" name="reset" value="Làm lại" /></li>
        </ul>
        </form>
    </div>
</div>