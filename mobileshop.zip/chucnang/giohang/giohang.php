<div class="prd-block">
	<h2>giỏ hàng của bạn</h2>
    <div class="cart">
    	<table width="100%">
        	<tr>
            	<td class="cart-item-img" width="25%" rowspan="4"><img width="80" height="144" src="anh/prd01.jpg" /></td>
                <td width="25%">Sản phẩm:</td>
                <td class="cart-item-title" width="50%">Samsung Galaxy Note Trắng</td>
            </tr>
            <tr>
                <td>Giá:</td>
                <td><span>6.800.000 VNĐ</span></td>
            </tr>
            <tr>
            	<td>Số lượng:</td>
                <td><input type="text" name="" value="4" /> (Bỏ mặt hàng này) <a href="#">X</a></td>
            </tr>
            <tr>
            	<td>Tổng tiền:</td>
                <td><span>27.200.000 VNĐ</span></td>
            </tr>
        </table>
        <table width="100%">
        	<tr>
            	<td class="cart-item-img" width="25%" rowspan="4"><img width="80" height="144" src="anh/prd02.jpg" /></td>
                <td width="25%">Sản phẩm:</td>
                <td class="cart-item-title" width="50%">Samsung Galaxy Note Trắng</td>
            </tr>
            <tr>
                <td>Giá:</td>
                <td><span>6.800.000 VNĐ</span></td>
            </tr>
            <tr>
            	<td>Số lượng:</td>
                <td><input type="text" name="" value="4" /> (Bỏ mặt hàng này) <a href="#">X</a></td>
            </tr>
            <tr>
            	<td>Tổng tiền:</td>
                <td><span>27.200.000 VNĐ</span></td>
            </tr>
        </table>
        <table width="100%">
        	<tr>
            	<td class="cart-item-img" width="25%" rowspan="4"><img width="80" height="144" src="anh/prd03.jpg" /></td>
                <td width="25%">Sản phẩm:</td>
                <td class="cart-item-title" width="50%">Samsung Galaxy Note Trắng</td>
            </tr>
            <tr>
                <td>Giá:</td>
                <td><span>6.800.000 VNĐ</span></td>
            </tr>
            <tr>
            	<td>Số lượng:</td>
                <td><input type="text" name="" value="4" /> (Bỏ mặt hàng này) <a href="#">X</a></td>
            </tr>
            <tr>
            	<td>Tổng tiền:</td>
                <td><span>27.200.000 VNĐ</span></td>
            </tr>
        </table>
        <table width="100%">
        	<tr>
            	<td class="cart-item-img" width="25%" rowspan="4"><img width="80" height="144" src="anh/prd04.jpg" /></td>
                <td width="25%">Sản phẩm:</td>
                <td class="cart-item-title" width="50%">Samsung Galaxy Note Trắng</td>
            </tr>
            <tr>
                <td>Giá:</td>
                <td><span>6.800.000 VNĐ</span></td>
            </tr>
            <tr>
            	<td>Số lượng:</td>
                <td><input type="text" name="" value="4" /> (Bỏ mặt hàng này) <a href="#">X</a></td>
            </tr>
            <tr>
            	<td>Tổng tiền:</td>
                <td><span>27.200.000 VNĐ</span></td>
            </tr>
        </table>

        <p>Tổng giá trị giỏ hàng là: <span>108.800.000 VNĐ</span></p>
        <p class="update-cart"><a href="#"><span>cập nhật giỏ hàng</span></a></p>
        <p><a href="#">Bổ sung sản phẩm</a> <span>•</span> <a href="#">Xóa hết sản phẩm</a> <span>•</span> <a href="#">Dừng mua và Thanh toán</a></p>
    </div>
</div>