<div id="cart">
    <p>Bạn đang có <span>01</span> sản phẩm</p>
    <p><a href="#">Chi tiết giỏ hàng</a></p>
</div>